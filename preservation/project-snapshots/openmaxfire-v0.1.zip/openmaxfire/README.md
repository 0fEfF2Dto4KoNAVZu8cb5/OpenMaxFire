# OpenMaxFire

OpenMaxFire is an open-source effort to preserve, document, and replace the discontinued Bixby **BixCheck** service software for MaxFire 110/115 biomass stoves.

## Goals

1. Preserve original Bixby software, firmware, manuals, release notes, and hardware documentation.
2. Fully document the MaxFire 110/115 J3 computer protocol.
3. Provide a modern, cross-platform Python API and CLI that can replace BixCheck for monitoring, normal control, configuration, diagnostics, and eventually firmware servicing.
4. Build an ESPHome hardware interface from the same documented protocol without making Home Assistant necessary for normal stove operation.
5. Keep factory combustion/safety firmware authoritative on production stoves.

## Current status — v0.1 research foundation

Statically reconstructed from BixCheck 5.5.01:

```text
Read register:          CRXX
Write register:         CWXXYY
Remote OFF:             CW0E11
Remote ON:              CW0E12
Remote UP:              CW0E14
Remote DOWN:            CW0E18
```

The remote commands are supported by direct disassembly evidence but **have not yet been validated on physical hardware**.

## Safety and reliability philosophy

OpenMaxFire must fail *out of the way*. Disconnecting, crashing, or removing OpenMaxFire must never prevent the factory front panel from operating the stove. The project does not replace factory combustion control in normal use.

Factory Checkout functions that directly actuate feed/ignition/blower hardware will remain isolated from the ordinary user API.

## Example

Without hardware, inspect a reconstructed command:

```bash
maxfirectl encode read 0x0E
# CR0E

maxfirectl encode button up
# CW0E14
```

Physical transmission is deliberately guarded until live validation is complete.

## Roadmap

- [x] Preserve known original package hashes
- [x] Recover register command encoding
- [x] Recover BixCheck remote button register/value mapping
- [ ] Decode response/ack framing
- [ ] Map complete controller register space
- [ ] Decode telemetry stream
- [ ] Implement read-only live monitor
- [ ] Validate remote buttons on physical MaxFire
- [ ] Configuration readback/backup
- [ ] Configuration editor with safety constraints
- [ ] Factory Checkout replacement
- [ ] Firmware identification/extraction
- [ ] Firmware downloader replacement
- [ ] ESPHome external component
- [ ] Optional modern service UI
