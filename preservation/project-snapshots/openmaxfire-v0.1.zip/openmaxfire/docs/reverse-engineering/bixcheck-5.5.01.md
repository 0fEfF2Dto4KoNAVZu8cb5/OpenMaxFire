# BixCheck 5.5.01 Reverse-Engineering Notes

Source artifact: `BixCheck_080315.exe` from the recovered factory `BixCheck_080315` package.

The PE32 binary retains unusually useful C++ symbol names, including:

- `bixby110io::getrs232port()`
- `bixby110io::sendcommand()`
- `bixby110io::regio()`
- `bixby110io::writereg()`
- `bixby110io::readreg()`
- `bixby110io::CollectResponse()`
- `bixby110io::CalculateChecksum()`
- `bixby110control::BixbyWriteRegister()`
- `bixby110checkout::SendInteractiveAction()`

## Remote-control evidence

`Bixby110RCButtonData` is located at VA `0x0043D380` in this build. The table contains OFF/ON/UP/DOWN entries with values `0x11`, `0x12`, `0x14`, and `0x18`.

At the remote-control UI handlers around VA `0x0041B0D7` and neighboring paths, BixCheck loads those values and calls:

`bixby110io::writereg('C', 0x0E, value)`

`writereg()` calls `regio()` with opcode `W`. `regio()` converts the address and value nibbles into uppercase hexadecimal ASCII. This reconstructs commands such as `CW0E14` for UP.

## Preservation rule

Addresses above are build-specific evidence for BixCheck 5.5.01. Do not assume they are stable across versions; preserve symbols, hashes, and per-build notes.
