# MaxFire 110/115 J3 Protocol — Working Specification

Status: **reverse-engineered, partially verified statically, not yet validated on physical hardware**.

## Controller register commands

Static analysis of `BixCheck_080315.exe` (BixCheck 5.5.01 / stove software 2.71) shows `bixby110io::readreg`, `writereg`, and `regio` constructing uppercase ASCII commands.

- Read register `XX`: `CRXX`
- Write value `YY` to register `XX`: `CWXXYY`

`XX` and `YY` are two uppercase hexadecimal digits.

## Remote front-panel control

BixCheck's `Bixby110RCButtonData` contains:

| Action | Value |
| --- | ---: |
| OFF | `0x11` |
| ON | `0x12` |
| UP | `0x14` |
| DOWN | `0x18` |

The remote-control handlers call `bixby110io::writereg('C', 0x0E, value)`, yielding the following reconstructed commands:

| Action | Command |
| --- | --- |
| OFF | `CW0E11` |
| ON | `CW0E12` |
| UP | `CW0E14` |
| DOWN | `CW0E18` |

These commands are **statically confirmed from BixCheck 5.5.01 but not yet live-tested on a stove**.

## Serial layer

Bixby release material and BixCheck 5.5.x indicate 19,200 baud for the 2.70/2.71 generation. Exact J3 electrical levels/pin order and serial framing must be verified before hardware connection.

## Next protocol milestones

1. Decode response framing and acknowledgement semantics from `scanio()` / `CollectResponse()`.
2. Build the controller register map.
3. Map telemetry records and state byte meanings.
4. Map EEPROM/configuration readback and write operations.
5. Map Checkout commands but keep them separate from normal-operation API.
6. Reverse-engineer firmware downloader only after read/normal-control layers are stable.
