from openmaxfire.protocol import (
    RemoteButton,
    encode_read_register,
    encode_remote_button,
    encode_write_register,
)


def test_read_register_encoding():
    assert encode_read_register(0x00) == b"CR00"
    assert encode_read_register(0x0E) == b"CR0E"
    assert encode_read_register(0xFF) == b"CRFF"


def test_write_register_encoding():
    assert encode_write_register(0x0E, 0x14) == b"CW0E14"
    assert encode_write_register(0xFF, 0x00) == b"CWFF00"


def test_remote_button_encodings_reconstructed_from_bixcheck_5501():
    assert encode_remote_button(RemoteButton.OFF) == b"CW0E11"
    assert encode_remote_button(RemoteButton.ON) == b"CW0E12"
    assert encode_remote_button(RemoteButton.UP) == b"CW0E14"
    assert encode_remote_button(RemoteButton.DOWN) == b"CW0E18"
