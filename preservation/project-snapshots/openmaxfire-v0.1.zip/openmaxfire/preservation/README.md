# Preservation manifest

Original Bixby vendor artifacts are intentionally **not modified** in this repository.

For every recovered artifact record:

- original filename
- SHA-256
- byte size
- source/provenance
- date recovered
- product/version association
- Archive.org identifier/URL once preserved

Derived files, extracted firmware, decompilation, protocol notes, and patches must be clearly labeled as derived work and never overwrite an original artifact.
